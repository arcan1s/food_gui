#!/bin/bash

cp -r usr /
python2 setup.py install --root=/
